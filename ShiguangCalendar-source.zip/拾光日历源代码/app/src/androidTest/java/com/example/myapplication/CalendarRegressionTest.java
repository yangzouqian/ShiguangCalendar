package com.example.myapplication;

import android.app.Instrumentation;
import android.content.Intent;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class CalendarRegressionTest {
    private final Instrumentation runner = InstrumentationRegistry.getInstrumentation();
    private MainActivity home;
    @Before public void open() {
        Intent intent = new Intent(runner.getTargetContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        home = (MainActivity) runner.startActivitySync(intent);
        runner.waitForIdleSync();
    }
    @After public void close() { runner.runOnMainSync(() -> home.finish()); }

    @Test public void navigationAndRecycledCellsDoNotLeakSelection() {
        runner.runOnMainSync(() -> {
            GridView grid = home.findViewById(R.id.grid_calendar);
            assertEquals(42, grid.getAdapter().getCount()); assertEquals(7, grid.getNumColumns());
            assertEquals("所选日期：" + MainActivity.todayDateString(),
                    ((TextView) home.findViewById(R.id.text_selected_date)).getText().toString());
            home.findViewById(R.id.button_next_month).performClick();
            assertFalse(home.findViewById(R.id.button_open_check_in).isEnabled());
            for (int i = 0; i < 42; i++) {
                if (grid.getAdapter().getItem(i) == null) assertFalse(grid.getAdapter().isEnabled(i));
            }
            home.findViewById(R.id.button_previous_month).performClick();
            assertEquals("所选日期：" + MainActivity.todayDateString(),
                    ((TextView) home.findViewById(R.id.text_selected_date)).getText().toString());
            for (int i = 0; i < 24; i++) home.findViewById(R.id.button_previous_month).performClick();
            assertTrue(((TextView) home.findViewById(R.id.text_selected_date)).getText().toString().endsWith("-01"));
            for (int i = 0; i < 24; i++) home.findViewById(R.id.button_next_month).performClick();
            assertTrue(home.findViewById(R.id.button_open_check_in).isEnabled());
        });
    }
}
