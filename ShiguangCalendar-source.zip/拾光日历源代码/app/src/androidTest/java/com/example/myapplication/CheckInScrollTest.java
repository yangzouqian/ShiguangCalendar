package com.example.myapplication;

import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.ScrollView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** 在真实 Android 视图树中分发触摸，覆盖外层滚动与六图点击。 */
@RunWith(AndroidJUnit4.class)
public class CheckInScrollTest {
    private final Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
    private CheckInActivity activity;
    private ScrollView scroll;

    @Before public void openPage() {
        Intent intent = new Intent(instrumentation.getTargetContext(), CheckInActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("selected_date", MainActivity.todayDateString());
        activity = (CheckInActivity) instrumentation.startActivitySync(intent);
        instrumentation.waitForIdleSync();
        instrumentation.runOnMainSync(() -> {
            View content = activity.findViewById(R.id.edit_content);
            android.view.ViewParent parent = content.getParent();
            while (!(parent instanceof ScrollView)) parent = parent.getParent();
            scroll = (ScrollView) parent;
            android.view.inputmethod.InputMethodManager keyboard =
                    (android.view.inputmethod.InputMethodManager) activity.getSystemService(
                            android.content.Context.INPUT_METHOD_SERVICE);
            keyboard.hideSoftInputFromWindow(content.getWindowToken(), 0);
            content.clearFocus();
        });
        SystemClock.sleep(300);
        instrumentation.waitForIdleSync();
    }

    @After public void closePage() {
        if (activity != null) instrumentation.runOnMainSync(() -> activity.finish());
    }

    private int topInContent(View view) {
        Rect rect = new Rect(0, 0, view.getWidth(), view.getHeight());
        scroll.offsetDescendantRectToMyCoords(view, rect);
        return rect.top;
    }

    private void dispatch(int action, long downTime, long time, float x, float y) {
        MotionEvent event = MotionEvent.obtain(downTime, time, action, x, y, 0);
        scroll.dispatchTouchEvent(event);
        event.recycle();
    }

    private void swipeUpOn(View target) {
        swipeOn(target, true);
    }

    private void swipeOn(View target, boolean up) {
        float[] points = new float[3];
        int[] before = new int[1];
        instrumentation.runOnMainSync(() -> {
            Rect visible = new Rect();
            assertTrue(target.getGlobalVisibleRect(visible));
            points[0] = visible.centerX();
            points[1] = up ? visible.bottom - 12 : visible.top + 12;
            points[2] = up ? Math.max(visible.top + 8, points[1] - 180)
                    : Math.min(visible.bottom - 8, points[1] + 180);
            before[0] = scroll.getScrollY();
        });
        long now = SystemClock.uptimeMillis();
        sendPointer(MotionEvent.ACTION_DOWN, now, points[0], points[1]);
        for (int i = 1; i <= 12; i++) {
            SystemClock.sleep(20);
            sendPointer(MotionEvent.ACTION_MOVE, now, points[0],
                    points[1] + (points[2] - points[1]) * i / 12);
        }
        sendPointer(MotionEvent.ACTION_UP, now, points[0], points[2]);
        instrumentation.waitForIdleSync();
        instrumentation.runOnMainSync(() -> assertTrue("Injected swipe must scroll outer content: before="
                + before[0] + ", after=" + scroll.getScrollY(), up
                ? scroll.getScrollY() > before[0] : scroll.getScrollY() < before[0]));
    }

    private void sendPointer(int action, long downTime, float x, float y) {
        MotionEvent event = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0);
        event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
        instrumentation.sendPointerSync(event);
        event.recycle();
    }

    @Test public void formAndGridHaveRealScrollRange() {
        instrumentation.runOnMainSync(() -> {
            GridView grid = activity.findViewById(R.id.grid_images);
            Log.i("CheckInScrollTest", "viewport=" + scroll.getHeight() + " content="
                    + scroll.getChildAt(0).getHeight() + " grid=" + grid.getHeight()
                    + " gridChildren=" + grid.getChildCount());
            assertTrue(scroll.getChildAt(0).getHeight() > scroll.getHeight());
            assertEquals(6, grid.getChildCount());
            View last = grid.getChildAt(5);
            assertTrue(last.getBottom() <= grid.getHeight() - grid.getPaddingBottom());
        });
    }

    @Test public void swipeFromBodyScrollsOuterPage() {
        instrumentation.runOnMainSync(() -> scroll.scrollTo(0, 0));
        swipeUpOn(activity.findViewById(R.id.edit_content));
    }

    @Test public void swipeFromImagesScrollsOuterPage() {
        View grid = activity.findViewById(R.id.grid_images);
        instrumentation.runOnMainSync(() -> scroll.scrollTo(0,
                Math.max(0, topInContent(grid) - scroll.getHeight() / 2)));
        swipeUpOn(grid);
    }

    @Test public void reverseSwipeFromImagesScrollsBack() {
        View grid = activity.findViewById(R.id.grid_images);
        instrumentation.runOnMainSync(() -> scroll.scrollTo(0,
                Math.max(0, topInContent(grid) - scroll.getHeight() / 2)));
        swipeOn(grid, false);
    }

    @Test public void allImagesAreClickableAndFooterStaysBelowViewport() {
        GridView grid = activity.findViewById(R.id.grid_images);
        for (int i = 0; i < 6; i++) {
            final int index = i;
            instrumentation.runOnMainSync(() -> {
                View cell = grid.getChildAt(index);
                scroll.scrollTo(0, Math.max(0, topInContent(cell) - 8));
                Rect visible = new Rect();
                assertTrue(cell.getGlobalVisibleRect(visible));
                assertEquals(cell.getHeight(), visible.height());
                int[] location = new int[2];
                scroll.getLocationOnScreen(location);
                float x = visible.centerX() - location[0];
                float y = visible.centerY() - location[1];
                long now = SystemClock.uptimeMillis();
                dispatch(MotionEvent.ACTION_DOWN, now, now, x, y);
                dispatch(MotionEvent.ACTION_UP, now, now + 80, x, y);
            });
            SystemClock.sleep(250);
            instrumentation.waitForIdleSync();
            instrumentation.runOnMainSync(() -> {
                assertTrue(grid.getChildAt(index).isActivated());
                String name = activity.getString(ImageAdapter.labelForCode(ImageAdapter.codeAt(index)));
                assertEquals(activity.getString(R.string.sg_image_preview, name),
                        activity.findViewById(R.id.image_preview).getContentDescription());
            });
        }
        instrumentation.runOnMainSync(() -> {
            scroll.fullScroll(View.FOCUS_DOWN);
            int[] viewport = new int[2];
            int[] save = new int[2];
            scroll.getLocationOnScreen(viewport);
            activity.findViewById(R.id.button_save_record).getLocationOnScreen(save);
            assertTrue(viewport[1] + scroll.getHeight() <= save[1]);
            android.widget.TextView identity = activity.findViewById(R.id.text_identity);
            assertTrue(identity.isShown());
            assertEquals("姓名：杨邹倩\n学号：2406100128", identity.getText().toString());
            ((android.widget.EditText) activity.findViewById(R.id.edit_content)).setText("");
            activity.findViewById(R.id.button_save_record).performClick();
            assertFalse(activity.isFinishing());
            activity.findViewById(R.id.button_return_calendar).performClick();
            assertTrue(activity.isFinishing());
        });
    }
}
