package com.example.myapplication;

import android.app.Instrumentation;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import com.example.myapplication.data.RecordStore;
import org.junit.*;
import org.junit.runner.RunWith;
import java.util.HashMap;
import java.util.Map;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class RecordFlowTest {
    private final Instrumentation runner = InstrumentationRegistry.getInstrumentation();
    private final String day = MainActivity.todayDateString();
    private final String[] fields = {"content", "mood", "image_code", "tag_study", "tag_sport",
            "tag_food", "tag_rest", "saved"};
    private SharedPreferences preferences;
    private final Map<String, Object> backup = new HashMap<>();
    private RecordStore store;
    private CheckInActivity page;
    private MainActivity home;

    @Before public void prepare() {
        preferences = runner.getTargetContext().getSharedPreferences(RecordStore.FILE_NAME, 0);
        Map<String, ?> original = preferences.getAll();
        SharedPreferences.Editor editor = preferences.edit();
        for (String field : fields) {
            String key = day + "_" + field;
            if (original.containsKey(key)) backup.put(key, original.get(key));
            editor.remove(key);
        }
        assertTrue(editor.commit());
        store = new RecordStore(preferences);
    }

    @After public void restore() {
        if (page != null) runner.runOnMainSync(() -> page.finish());
        if (home != null) runner.runOnMainSync(() -> home.finish());
        SharedPreferences.Editor editor = preferences.edit();
        for (String field : fields) {
            String key = day + "_" + field;
            Object value = backup.get(key);
            if (value instanceof String) editor.putString(key, (String) value);
            else if (value instanceof Boolean) editor.putBoolean(key, (Boolean) value);
            else editor.remove(key);
        }
        assertTrue(editor.commit());
    }

    private void open() {
        Intent intent = new Intent(runner.getTargetContext(), CheckInActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("selected_date", day);
        page = (CheckInActivity) runner.startActivitySync(intent);
        runner.waitForIdleSync();
    }

    @Test public void keyboardKeepsFooterVisibleAndFormScrollable() {
        open();
        runner.runOnMainSync(() -> {
            EditText input = page.findViewById(R.id.edit_content);
            input.requestFocus();
            ((android.view.inputmethod.InputMethodManager) page.getSystemService(Context.INPUT_METHOD_SERVICE))
                    .showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        });
        android.os.SystemClock.sleep(1000);
        runner.waitForIdleSync();
        runner.runOnMainSync(() -> {
            android.view.View root = page.findViewById(R.id.check_in_root);
            assertTrue("IME must actually be visible", root.getRootWindowInsets().isVisible(android.view.WindowInsets.Type.ime()));
            android.graphics.Rect bounds = new android.graphics.Rect();
            android.view.View identity = page.findViewById(R.id.text_identity);
            assertTrue(identity.getGlobalVisibleRect(bounds));
            assertEquals(identity.getHeight(), bounds.height());
            ScrollView scroll = page.findViewById(R.id.scroll_check_in);
            assertTrue("Content viewport must remain usable", scroll.getHeight() > 0);
            int[] button = new int[2], viewport = new int[2];
            page.findViewById(R.id.button_save_record).getLocationOnScreen(button);
            scroll.getLocationOnScreen(viewport);
            assertTrue(viewport[1] + scroll.getHeight() <= button[1]);
            scroll.scrollTo(0, scroll.getChildAt(0).getHeight());
            assertTrue(scroll.getScrollY() > 0);
        });
    }

    @Test public void recreationKeepsUnsavedFormAndImageWithoutWritingRecord() {
        open();
        runner.runOnMainSync(() -> {
            ((EditText) page.findViewById(R.id.edit_content)).setText("未保存😀");
            ((RadioGroup) page.findViewById(R.id.group_mood)).check(R.id.mood_low);
            ((CheckBox) page.findViewById(R.id.tag_food)).setChecked(true);
            GridView grid = page.findViewById(R.id.grid_images);
            grid.performItemClick(grid.getChildAt(4), 4, 4);
        });
        Instrumentation.ActivityMonitor monitor = runner.addMonitor(CheckInActivity.class.getName(), null, false);
        try {
            runner.runOnMainSync(() -> page.recreate());
            page = (CheckInActivity) runner.waitForMonitorWithTimeout(monitor, 5000);
            assertNotNull(page);
            runner.waitForIdleSync();
            runner.runOnMainSync(() -> {
                assertEquals("未保存😀", ((EditText) page.findViewById(R.id.edit_content)).getText().toString());
                assertEquals(R.id.mood_low, ((RadioGroup) page.findViewById(R.id.group_mood)).getCheckedRadioButtonId());
                assertTrue(((CheckBox) page.findViewById(R.id.tag_food)).isChecked());
                assertEquals("所选配图预览：风景", page.findViewById(R.id.image_preview).getContentDescription());
                assertFalse(store.isSaved(day));
            });
        } finally { runner.removeMonitor(monitor); }
    }

    @Test public void savingReturnsToHomeAndImmediatelyRefreshesMarker() {
        Intent intent = new Intent(runner.getTargetContext(), MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        home = (MainActivity) runner.startActivitySync(intent);
        runner.waitForIdleSync();
        Instrumentation.ActivityMonitor monitor = runner.addMonitor(CheckInActivity.class.getName(), null, false);
        try {
            runner.runOnMainSync(() -> home.findViewById(R.id.button_open_check_in).performClick());
            page = (CheckInActivity) runner.waitForMonitorWithTimeout(monitor, 5000);
            assertNotNull(page);
            runner.waitForIdleSync();
            runner.runOnMainSync(() -> {
                ((EditText) page.findViewById(R.id.edit_content)).setText("首页标记验证");
                page.findViewById(R.id.button_save_record).performClick();
            });
            runner.waitForIdleSync();
            android.os.SystemClock.sleep(300);
            runner.waitForIdleSync();
            runner.runOnMainSync(() -> {
                GridView calendar = home.findViewById(R.id.grid_calendar);
                boolean marked = false;
                for (int i = 0; i < calendar.getChildCount(); i++) {
                    CharSequence description = calendar.getChildAt(i).getContentDescription();
                    if (description != null && description.toString().startsWith(day)) {
                        marked = description.toString().contains("已记");
                        assertTrue(((TextView) calendar.getChildAt(i)).getText().toString().contains("•"));
                    }
                }
                assertTrue("onResume must refresh today's saved marker", marked);
            });
        } finally {
            runner.removeMonitor(monitor);
        }
    }

    @Test public void newDateDefaultsAndUnsavedReturnAndInvalidInput() {
        open();
        runner.runOnMainSync(() -> {
            EditText content = page.findViewById(R.id.edit_content);
            assertEquals("", content.getText().toString());
            assertEquals(R.id.mood_calm, ((RadioGroup) page.findViewById(R.id.group_mood)).getCheckedRadioButtonId());
            for (int id : new int[]{R.id.tag_study,R.id.tag_sport,R.id.tag_food,R.id.tag_rest})
                assertFalse(((CheckBox) page.findViewById(id)).isChecked());
            assertEquals("所选配图预览：读书", page.findViewById(R.id.image_preview).getContentDescription());
            content.setText(" \n ");
            page.findViewById(R.id.button_save_record).performClick();
            assertFalse(page.isFinishing()); assertEquals(" \n ", content.getText().toString());
            assertFalse(store.isSaved(day));
            StringBuilder longText = new StringBuilder();
            for (int i = 0; i < 301; i++) longText.append("字");
            content.setText(longText.toString());
            page.findViewById(R.id.button_save_record).performClick();
            assertFalse(page.isFinishing()); assertEquals(301, content.length());
            content.setText("不保存");
            page.findViewById(R.id.button_return_calendar).performClick();
            assertFalse(store.isSaved(day));
        });
    }

    @Test public void saveReopenOverwriteAndCancel() {
        open();
        runner.runOnMainSync(() -> {
            ((EditText) page.findViewById(R.id.edit_content)).setText("  正文😀  ");
            ((RadioGroup) page.findViewById(R.id.group_mood)).check(R.id.mood_happy);
            for (int id : new int[]{R.id.tag_study,R.id.tag_sport,R.id.tag_food,R.id.tag_rest})
                ((CheckBox) page.findViewById(id)).setChecked(true);
            GridView grid = page.findViewById(R.id.grid_images);
            grid.performItemClick(grid.getChildAt(2), 2, 2);
            page.findViewById(R.id.button_save_record).performClick();
            assertTrue(page.isFinishing());
        });
        runner.waitForIdleSync();
        open();
        runner.runOnMainSync(() -> {
            assertEquals("正文😀", ((EditText) page.findViewById(R.id.edit_content)).getText().toString());
            assertEquals(R.id.mood_happy, ((RadioGroup) page.findViewById(R.id.group_mood)).getCheckedRadioButtonId());
            for (int id : new int[]{R.id.tag_study,R.id.tag_sport,R.id.tag_food,R.id.tag_rest})
                assertTrue(((CheckBox) page.findViewById(id)).isChecked());
            assertEquals("所选配图预览：美食", page.findViewById(R.id.image_preview).getContentDescription());
            ((EditText) page.findViewById(R.id.edit_content)).setText("修改");
            ((RadioGroup) page.findViewById(R.id.group_mood)).check(R.id.mood_low);
            for (int id : new int[]{R.id.tag_study,R.id.tag_sport,R.id.tag_food,R.id.tag_rest})
                ((CheckBox) page.findViewById(id)).setChecked(false);
            GridView grid = page.findViewById(R.id.grid_images);
            grid.performItemClick(grid.getChildAt(5), 5, 5);
            page.findViewById(R.id.button_save_record).performClick();
        });
        runner.waitForIdleSync();
        open();
        runner.runOnMainSync(() -> {
            assertEquals("修改", ((EditText) page.findViewById(R.id.edit_content)).getText().toString());
            assertEquals(R.id.mood_low, ((RadioGroup) page.findViewById(R.id.group_mood)).getCheckedRadioButtonId());
            for (int id : new int[]{R.id.tag_study,R.id.tag_sport,R.id.tag_food,R.id.tag_rest})
                assertFalse(((CheckBox) page.findViewById(id)).isChecked());
            assertEquals("所选配图预览：休息", page.findViewById(R.id.image_preview).getContentDescription());
            ((EditText) page.findViewById(R.id.edit_content)).setText("取消修改");
            page.findViewById(R.id.button_return_calendar).performClick();
            assertEquals("修改", store.read(day).content);
        });
    }
}
