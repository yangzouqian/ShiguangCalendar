package com.example.myapplication;
import android.content.*;
import android.widget.*;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.example.myapplication.data.RecordStore;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** 两个独立测试进程之间由宿主执行 force-stop，验证磁盘保留而非内存缓存。 */
@RunWith(AndroidJUnit4.class)
public class ProcessRestartTest {
    private final Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
    private final String day = "2000-01-02";
    private final String[] fields = {"content","mood","image_code","tag_study","tag_sport","tag_food","tag_rest","saved"};
    @Test public void seedBeforeStop() throws Exception {
        SharedPreferences prefs = context.getSharedPreferences(RecordStore.FILE_NAME, 0);
        SharedPreferences backup = context.getSharedPreferences("sg_restart_test_backup", 0);
        assertFalse("Do not overwrite an unfinished test backup", backup.getBoolean("active", false));
        SharedPreferences.Editor copy = backup.edit().putBoolean("active", true);
        for (String field : fields) {
            Object value = prefs.getAll().get(day + "_" + field);
            if (value instanceof String) copy.putString(field, (String)value);
            if (value instanceof Boolean) copy.putBoolean(field, (Boolean)value);
        }
        assertTrue(copy.commit());
        assertTrue(new RecordStore(context).save(day, new RecordStore.Record(
                "重启验证😀", "低落", "walk", true, false, true, false, true)));
        Thread.sleep(500);
    }
    @Test public void verifyAfterStopAndRestore() {
        SharedPreferences prefs = context.getSharedPreferences(RecordStore.FILE_NAME, 0);
        SharedPreferences backup = context.getSharedPreferences("sg_restart_test_backup", 0);
        assertTrue(backup.getBoolean("active", false));
        try {
            RecordStore.Record r = new RecordStore(context).read(day);
            assertEquals("重启验证😀", r.content); assertEquals("低落", r.mood);
            assertEquals("walk", r.imageCode); assertTrue(r.saved && r.study && r.food);
            assertFalse(r.sport || r.rest);
            android.app.Instrumentation runner = InstrumentationRegistry.getInstrumentation();
            Intent intent = new Intent(context, CheckInActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("selected_date", day);
            CheckInActivity page = (CheckInActivity) runner.startActivitySync(intent);
            runner.waitForIdleSync();
            runner.runOnMainSync(() -> {
                assertEquals("重启验证😀", ((EditText) page.findViewById(R.id.edit_content)).getText().toString());
                assertEquals("所选配图预览：散步", page.findViewById(R.id.image_preview).getContentDescription());
                page.finish();
            });
        } finally {
            SharedPreferences.Editor restore = prefs.edit();
            for (String field : fields) {
                Object value = backup.getAll().get(field);
                String key = day + "_" + field;
                if (value instanceof String) restore.putString(key, (String)value);
                else if (value instanceof Boolean) restore.putBoolean(key, (Boolean)value);
                else restore.remove(key);
            }
            assertTrue(restore.commit());
            assertTrue(backup.edit().clear().commit());
        }
    }
}
