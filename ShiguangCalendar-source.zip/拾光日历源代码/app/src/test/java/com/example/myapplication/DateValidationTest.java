package com.example.myapplication;

import org.junit.Test;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import static org.junit.Assert.*;

public class DateValidationTest {
    @Test public void todayAndPastAreAccepted() {
        assertTrue(MainActivity.todayDateString().matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"));
        assertEquals(0, MainActivity.validateDate(MainActivity.todayDateString()));
        assertEquals(0, MainActivity.validateDate("2024-02-29"));
        assertEquals(0, MainActivity.validateDate("2026-01-01"));
    }

    @Test public void tomorrowIsRejected() {
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        String value = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(tomorrow.getTime());
        assertEquals(R.string.sg_date_future, MainActivity.validateDate(value));
    }

    @Test public void missingDatesAreRejected() {
        assertEquals(R.string.sg_date_missing, MainActivity.validateDate(null));
        assertEquals(R.string.sg_date_missing, MainActivity.validateDate(""));
        assertEquals(R.string.sg_date_missing, MainActivity.validateDate("   "));
    }

    @Test public void malformedDatesAreRejected() {
        for (String value : new String[]{"2026-2-01", "2026/02/01", " 2026-02-01",
                "2026-02-01 ", "2026-02-01extra", "２０２６-０２-０１"}) {
            assertEquals(value, R.string.sg_date_format_error, MainActivity.validateDate(value));
        }
    }

    @Test public void nonexistentDatesAreRejectedWithoutCorrection() {
        for (String value : new String[]{"2026-02-30", "2025-02-29", "2026-13-01",
                "2026-00-01", "2026-01-00", "0000-01-01"}) {
            assertEquals(value, R.string.sg_date_nonexistent, MainActivity.validateDate(value));
        }
    }
}
