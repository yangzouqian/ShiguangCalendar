package com.example.myapplication;

import org.junit.Test;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import static org.junit.Assert.*;

public class CalendarLogicTest {
    private Calendar month(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(year, month - 1, 1);
        return calendar;
    }

    @Test public void leapAndCommonFebruary() {
        Set<String> leap = dates(month(2024, 2));
        Set<String> common = dates(month(2025, 2));
        assertEquals(29, leap.size());
        assertTrue(leap.contains("2024-02-29"));
        assertEquals(28, common.size());
        assertFalse(common.contains("2025-02-29"));
        assertEquals(28, dates(month(2100, 2)).size());
        assertEquals(29, dates(month(2000, 2)).size());
    }

    private Set<String> dates(Calendar month) {
        Set<String> result = new HashSet<>();
        for (String date : CalendarAdapter.buildMonthDates(month)) {
            if (date != null) result.add(date);
        }
        return result;
    }

    @Test public void mondayAndSundayStarts() {
        String[] monday = CalendarAdapter.buildMonthDates(month(2026, 6));
        assertEquals("2026-06-01", monday[0]);
        String[] sunday = CalendarAdapter.buildMonthDates(month(2026, 2));
        for (int i = 0; i < 6; i++) assertNull(sunday[i]);
        assertEquals("2026-02-01", sunday[6]);
        assertEquals("2026-02-28", sunday[33]);
        for (int i = 34; i < 42; i++) assertNull(sunday[i]);
    }

    @Test public void everyMonthHas42CellsWithCorrectWeekdayAndPadding() {
        for (int year = 1996; year <= 2032; year++) {
            for (int m = 1; m <= 12; m++) {
                Calendar calendar = month(year, m);
                String[] cells = CalendarAdapter.buildMonthDates(calendar);
                assertEquals(42, cells.length);
                int day = 0;
                for (int position = 0; position < cells.length; position++) {
                    if (cells[position] == null) continue;
                    day++;
                    calendar.set(Calendar.DAY_OF_MONTH, day);
                    assertEquals((calendar.get(Calendar.DAY_OF_WEEK) + 5) % 7, position % 7);
                    assertEquals(day, Integer.parseInt(cells[position].substring(8)));
                    assertTrue(cells[position].matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"));
                }
                assertEquals(calendar.getActualMaximum(Calendar.DAY_OF_MONTH), day);
                assertEquals(day, dates(calendar).size());
            }
        }
    }

    @Test public void navigationCrossesYearAndNeverSkipsFebruary() {
        Calendar january = CalendarAdapter.shiftedMonth(month(2025, 12), 1);
        assertEquals(2026, january.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, january.get(Calendar.MONTH));
        Calendar december = CalendarAdapter.shiftedMonth(january, -1);
        assertEquals(2025, december.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, december.get(Calendar.MONTH));
        Calendar lastDay = month(2026, 1);
        lastDay.set(Calendar.DAY_OF_MONTH, 31);
        Calendar february = CalendarAdapter.shiftedMonth(lastDay, 1);
        assertEquals(Calendar.FEBRUARY, february.get(Calendar.MONTH));
        assertEquals(1, february.get(Calendar.DAY_OF_MONTH));
        assertEquals(31, lastDay.get(Calendar.DAY_OF_MONTH));
    }

    @Test public void selectionRulesForPastCurrentAndFutureMonths() {
        String today = "2026-10-30";
        assertEquals("2026-09-01", CalendarAdapter.defaultSelection(month(2026, 9), today));
        assertEquals(today, CalendarAdapter.defaultSelection(month(2026, 10), today));
        assertNull(CalendarAdapter.defaultSelection(month(2026, 11), today));
        assertNull(CalendarAdapter.defaultSelection(month(2027, 1), today));
    }

    @Test public void currentMonthContainsActualToday() {
        assertTrue(dates(Calendar.getInstance()).contains(MainActivity.todayDateString()));
    }
}
