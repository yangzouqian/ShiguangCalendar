package com.example.myapplication;

import org.junit.Test;
import java.util.HashSet;
import java.util.Set;
import static org.junit.Assert.*;

public class ImageAdapterTest {
    @Test public void stableOrderHasSixUniqueResourcesAndLabels() {
        String[] expected = {"study", "sport", "food", "walk", "view", "rest"};
        Set<Integer> images = new HashSet<>();
        Set<Integer> labels = new HashSet<>();
        for (int i = 0; i < expected.length; i++) {
            assertEquals(expected[i], ImageAdapter.codeAt(i));
            assertEquals(i, ImageAdapter.indexForCode(expected[i]));
            assertEquals(expected[i], ImageAdapter.normalizeCode(expected[i]));
            images.add(ImageAdapter.imageForCode(expected[i]));
            labels.add(ImageAdapter.labelForCode(expected[i]));
        }
        assertEquals(6, images.size());
        assertEquals(6, labels.size());
        assertEquals(R.drawable.sg_image_study, ImageAdapter.imageForCode("study"));
        assertEquals(R.drawable.sg_image_rest, ImageAdapter.imageForCode("rest"));
    }

    @Test public void unknownOrMissingCodeFallsBackToStudy() {
        for (String code : new String[]{null, "", "unknown", "STUDY"}) {
            assertEquals("study", ImageAdapter.normalizeCode(code));
            assertEquals(R.drawable.sg_image_study, ImageAdapter.imageForCode(code));
            assertEquals(R.string.sg_image_study, ImageAdapter.labelForCode(code));
        }
    }
}
