package com.example.myapplication.data;

import android.content.SharedPreferences;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

public class RecordStoreTest {
    // 仅替代 Android 的存储接口；RecordStore 的真实读写和校验代码直接运行。
    private final Map<String, Object> values = new HashMap<>();
    private int edits, applies, writes;
    private final SharedPreferences preferences = (SharedPreferences) Proxy.newProxyInstance(
            SharedPreferences.class.getClassLoader(), new Class[]{SharedPreferences.class}, (p, m, a) -> {
                if (m.getName().equals("getString") || m.getName().equals("getBoolean"))
                    return values.getOrDefault(a[0], a[1]);
                if (m.getName().equals("edit")) {
                    edits++;
                    Map<String, Object> pending = new HashMap<>();
                    return Proxy.newProxyInstance(SharedPreferences.Editor.class.getClassLoader(),
                            new Class[]{SharedPreferences.Editor.class}, (editor, method, args) -> {
                                if (method.getName().startsWith("put")) {
                                    writes++;
                                    pending.put((String) args[0], args[1]);
                                    return editor;
                                }
                                if (method.getName().equals("apply")) {
                                    applies++;
                                    values.putAll(pending);
                                    return null;
                                }
                                throw new AssertionError("Unexpected editor call: " + method.getName());
                            });
                }
                throw new AssertionError("Unexpected preference call: " + m.getName());
            });
    private final RecordStore store = new RecordStore(preferences);
    private static final String DAY = "2026-10-01";

    private RecordStore.Record record(String text) {
        return new RecordStore.Record(text, "开心", "food", true, true, true, true, true);
    }

    @Test public void newDateHasDefaults() {
        RecordStore.Record r = store.read(DAY);
        assertEquals("", r.content); assertEquals("平静", r.mood); assertEquals("study", r.imageCode);
        assertFalse(r.saved); assertFalse(r.study); assertFalse(r.sport); assertFalse(r.food); assertFalse(r.rest);
        assertEquals(0, edits);
    }
    @Test public void writesAndReadsAllEightFieldsWithOneApply() {
        assertTrue(store.save(DAY, record("  正文  ")));
        RecordStore.Record r = store.read(DAY);
        assertEquals("正文", r.content); assertEquals("开心", r.mood); assertEquals("food", r.imageCode);
        assertTrue(r.saved && r.study && r.sport && r.food && r.rest);
        assertEquals(8, values.size()); assertEquals(8, writes); assertEquals(1, edits); assertEquals(1, applies);
        assertEquals("正文", values.get(DAY + "_content"));
        assertEquals("food", values.get(DAY + "_image_code"));
        assertEquals(true, values.get(DAY + "_saved"));
    }
    @Test public void sameDateCompletelyOverwrites() {
        store.save(DAY, record("旧"));
        store.save(DAY, new RecordStore.Record("新", "低落", "rest", false, false, false, false, true));
        RecordStore.Record r = store.read(DAY);
        assertEquals("新", r.content); assertEquals("低落", r.mood); assertEquals("rest", r.imageCode);
        assertFalse(r.study || r.sport || r.food || r.rest);
        assertEquals(8, values.size()); assertEquals(16, writes); assertEquals(2, applies);
    }
    @Test public void cancelledTagsAreWrittenAsFalse() {
        store.save(DAY, record("旧"));
        store.save(DAY, new RecordStore.Record("新", "平静", "study", false, true, false, true, true));
        assertEquals(false, values.get(DAY + "_tag_study"));
        assertEquals(false, values.get(DAY + "_tag_food"));
        assertTrue(store.read(DAY).sport && store.read(DAY).rest);
    }
    @Test public void changedImageIsRestored() {
        store.save(DAY, record("正文"));
        store.save(DAY, new RecordStore.Record("正文", "平静", "walk", false, false, false, false, true));
        assertEquals("walk", new RecordStore(preferences).read(DAY).imageCode);
    }
    @Test public void differentDatesAreIndependent() {
        store.save(DAY, record("甲")); store.save("2026-10-02", record("乙"));
        store.save(DAY, record("丙"));
        assertEquals("乙", store.read("2026-10-02").content);
        assertEquals("丙", store.read(DAY).content); assertEquals(16, values.size());
    }
    @Test public void blankTextNeverStartsAnEdit() {
        for (String text : new String[]{null, "", " \n\t", "\u3000\u00a0"})
            assertFalse(store.save(DAY, record(text)));
        assertEquals(0, edits); assertFalse(store.isSaved(DAY));
    }
    private String repeat(String value, int count) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) result.append(value);
        return result.toString();
    }
    @Test public void accepts300CodePoints() {
        assertTrue(store.save(DAY, record(repeat("字", 300))));
        assertEquals(300, RecordStore.contentLength(store.read(DAY).content));
    }
    @Test public void rejects301WithoutChangingExistingRecord() {
        store.save(DAY, record("旧记录"));
        assertFalse(store.save(DAY, record(repeat("字", 301))));
        assertEquals("旧记录", store.read(DAY).content); assertEquals(1, applies);
    }
    @Test public void supplementaryEmojiCountAsOneCodePoint() {
        String emoji = "\uD83D\uDE00";
        assertEquals(1, RecordStore.contentLength(emoji));
        assertTrue(store.save(DAY, record(repeat(emoji, 300))));
        assertFalse(store.save(DAY, record(repeat(emoji, 301))));
        assertEquals(600, store.read(DAY).content.length());
    }
    @Test public void readingAndUnsavedEditsDoNotWrite() {
        store.read(DAY);
        RecordStore.Record unsaved = record("仅编辑");
        assertFalse(store.isSaved(DAY)); assertEquals(0, applies);
        store.save(DAY, record("正式记录"));
        store.read(DAY);
        assertEquals("正式记录", store.read(DAY).content); assertEquals(1, applies);
    }
    @Test public void reopenedStoreReadsAllFields() {
        store.save(DAY, record("再次读取"));
        RecordStore.Record r = new RecordStore(preferences).read(DAY);
        assertEquals("再次读取", r.content); assertEquals("开心", r.mood); assertEquals("food", r.imageCode);
        assertTrue(r.study && r.sport && r.food && r.rest && r.saved);
    }
    @Test public void orphanFieldsWithoutSavedFlagAreIgnored() {
        values.put(DAY + "_content", "残留"); values.put(DAY + "_image_code", "rest");
        assertEquals("", store.read(DAY).content); assertEquals("study", store.read(DAY).imageCode);
    }
}
