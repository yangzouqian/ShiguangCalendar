package com.example.myapplication;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Set;
import java.util.HashSet;

/** 只负责月历数据与显示，不读取或保存打卡记录。 */
public class CalendarAdapter extends BaseAdapter {
    private final Context context;
    private final int normalTextColor;
    private String[] dates = new String[42];
    private String selectedDate;
    private String today;
    private Set<String> savedDates = new HashSet<>();

    public CalendarAdapter(Context context) {
        this.context = context;
        TypedArray colors = context.obtainStyledAttributes(new int[]{android.R.attr.textColorPrimary});
        normalTextColor = colors.getColor(0, Color.DKGRAY);
        colors.recycle();
    }

    public void update(Calendar month, String selectedDate, String today, Set<String> savedDates) {
        dates = buildMonthDates(month);
        this.selectedDate = selectedDate;
        this.today = today;
        this.savedDates = new HashSet<>(savedDates);
        notifyDataSetChanged();
    }

    /** 星期一起始；null 是不可点击的月初、月末补位。月份使用 Calendar 的零基月份。 */
    static String[] buildMonthDates(Calendar month) {
        Calendar day = (Calendar) month.clone();
        day.set(Calendar.DAY_OF_MONTH, 1);
        int offset = (day.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        int count = day.getActualMaximum(Calendar.DAY_OF_MONTH);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        String[] result = new String[42];
        for (int number = 1; number <= count; number++) {
            day.set(Calendar.DAY_OF_MONTH, number);
            result[offset + number - 1] = format.format(day.getTime());
        }
        return result;
    }

    static Calendar shiftedMonth(Calendar month, int amount) {
        Calendar result = (Calendar) month.clone();
        result.set(Calendar.DAY_OF_MONTH, 1);
        result.add(Calendar.MONTH, amount);
        return result;
    }

    static String defaultSelection(Calendar month, String today) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM", Locale.ROOT);
        String prefix = format.format(month.getTime());
        int comparison = prefix.compareTo(today.substring(0, 7));
        if (comparison > 0) return null;
        return comparison == 0 ? today : prefix + "-01";
    }

    @Override public int getCount() { return dates.length; }
    @Override public String getItem(int position) { return dates[position]; }
    @Override public long getItemId(int position) { return position; }
    @Override public boolean areAllItemsEnabled() { return false; }
    @Override public boolean isEnabled(int position) { return dates[position] != null; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        TextView cell = (TextView) convertView;
        if (cell == null) {
            cell = (TextView) LayoutInflater.from(context).inflate(
                    R.layout.item_calendar_day, parent, false);
        }
        String date = dates[position];
        boolean blank = date == null;
        boolean isToday = !blank && date.equals(today);
        boolean selected = !blank && date.equals(selectedDate);
        boolean future = !blank && date.compareTo(today) > 0;
        boolean saved = !blank && savedDates.contains(date);

        // 完整重置复用格子的文字、背景、可用性与无障碍描述。
        cell.setText(blank ? "" : Integer.parseInt(date.substring(8))
                + (isToday ? (saved ? " •\n今天" : "\n今天")
                : saved ? "\n" + context.getString(R.string.sg_calendar_saved) : ""));
        cell.setEnabled(!blank);
        cell.setSelected(selected);
        cell.setTypeface(null, selected || isToday ? Typeface.BOLD : Typeface.NORMAL);
        cell.setTextColor(selected ? Color.WHITE : future ? Color.rgb(140, 140, 140)
                : isToday ? Color.rgb(103, 80, 164) : normalTextColor);
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(8 * context.getResources().getDisplayMetrics().density);
        background.setColor(selected ? Color.rgb(103, 80, 164) : Color.TRANSPARENT);
        if (isToday) {
            background.setStroke((int) Math.ceil(2 * context.getResources().getDisplayMetrics().density),
                    selected ? Color.rgb(221, 200, 255) : Color.rgb(103, 80, 164));
        }
        cell.setBackground(background);
        cell.setContentDescription(blank ? null : date
                + (isToday ? "，今天" : "") + (selected ? "，已选中" : "")
                + (future ? "，未来日期不可记录" : "") + (saved ? "，已记" : ""));
        return cell;
    }
}
