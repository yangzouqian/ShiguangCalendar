package com.example.myapplication.data;

import android.content.Context;
import android.content.SharedPreferences;

/** 少量日期记录的统一存储入口。一次保存完整覆盖八个字段。 */
public final class RecordStore {
    public static final String FILE_NAME = "com.example.shiguang.records";
    private final SharedPreferences preferences;

    public RecordStore(Context context) {
        this(context.getApplicationContext().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE));
    }

    public RecordStore(SharedPreferences preferences) {
        this.preferences = preferences;
    }

    public static final class Record {
        public final String content, mood, imageCode;
        public final boolean study, sport, food, rest, saved;

        public Record(String content, String mood, String imageCode, boolean study,
                      boolean sport, boolean food, boolean rest, boolean saved) {
            this.content = content;
            this.mood = mood;
            this.imageCode = imageCode;
            this.study = study;
            this.sport = sport;
            this.food = food;
            this.rest = rest;
            this.saved = saved;
        }
    }

    public boolean isSaved(String date) {
        return preferences.getBoolean(date + "_saved", false);
    }

    public Record read(String date) {
        if (!isSaved(date)) return new Record("", "平静", "study", false, false, false, false, false);
        String prefix = date + "_";
        return new Record(preferences.getString(prefix + "content", ""),
                preferences.getString(prefix + "mood", "平静"),
                preferences.getString(prefix + "image_code", "study"),
                preferences.getBoolean(prefix + "tag_study", false),
                preferences.getBoolean(prefix + "tag_sport", false),
                preferences.getBoolean(prefix + "tag_food", false),
                preferences.getBoolean(prefix + "tag_rest", false), true);
    }

    /** 同时去掉常规空白和 Unicode 空格；不更改正文内部的内容。 */
    public static String trimContent(String text) {
        if (text == null) return "";
        int start = 0, end = text.length();
        while (start < end && isSpace(text.codePointAt(start))) {
            start += Character.charCount(text.codePointAt(start));
        }
        while (end > start && isSpace(text.codePointBefore(end))) {
            end -= Character.charCount(text.codePointBefore(end));
        }
        return text.substring(start, end);
    }

    private static boolean isSpace(int codePoint) {
        return Character.isWhitespace(codePoint) || Character.isSpaceChar(codePoint);
    }

    public static int contentLength(String text) {
        String trimmed = trimContent(text);
        return trimmed.codePointCount(0, trimmed.length());
    }

    /** 校验失败时不创建 Editor。apply 更新内存并安排异步写盘，不返回写盘结果。 */
    public boolean save(String date, Record record) {
        String content = trimContent(record.content);
        int length = content.codePointCount(0, content.length());
        if (length < 1 || length > 300) return false;
        String prefix = date + "_";
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(prefix + "content", content);
        editor.putString(prefix + "mood", record.mood);
        editor.putString(prefix + "image_code", record.imageCode);
        editor.putBoolean(prefix + "tag_study", record.study);
        editor.putBoolean(prefix + "tag_sport", record.sport);
        editor.putBoolean(prefix + "tag_food", record.food);
        editor.putBoolean(prefix + "tag_rest", record.rest);
        editor.putBoolean(prefix + "saved", true);
        editor.apply();
        return true;
    }
}
