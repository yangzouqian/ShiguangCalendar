package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.ScrollView;

/** 打卡表单的唯一纵向滚动容器；点击仍交由正文、选项和图片处理。 */
public class CheckInScrollView extends ScrollView {
    private final int touchSlop;
    private float downX;
    private float downY;

    public CheckInScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
        } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            float dx = Math.abs(event.getX() - downX);
            float dy = Math.abs(event.getY() - downY);
            if (dy > touchSlop && dy > dx) {
                // EditText、AbsListView 可能要求父容器禁止拦截。
                // 明确的纵向拖动恢复外层拦截，让 ScrollView 给子项发送 CANCEL，
                // 小范围点击和横向手势仍由原控件处理。
                super.requestDisallowInterceptTouchEvent(false);
            }
        }
        return super.dispatchTouchEvent(event);
    }
}
