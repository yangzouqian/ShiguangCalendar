package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.GridView;

/** 在外层 ScrollView 中展开全部行，避免固定高度裁剪及内外两层纵向滚动。 */
public class ExpandedHeightGridView extends GridView {
    public ExpandedHeightGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setNestedScrollingEnabled(false);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        // 所有行已展开，无须 GridView 拦截并启动内部滚动。
        // 短按继续由 GridView 原有 onTouchEvent 识别并触发选图监听。
        return false;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 六张本地图片是有界的小集合。保留父布局给定的宽度，让 GridView
        // 按实际单元格、行间距、字体和像素取整结果计算全部行的高度。
        int expandedHeightSpec = MeasureSpec.makeMeasureSpec(
                Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, expandedHeightSpec);
    }
}
