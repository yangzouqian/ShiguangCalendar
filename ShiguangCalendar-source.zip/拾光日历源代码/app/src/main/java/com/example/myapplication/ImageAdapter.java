package com.example.myapplication;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/** 六张内置配图的固定顺序与稳定编号；不涉及持久化。 */
public class ImageAdapter extends BaseAdapter {
    private static final String[] CODES = {"study", "sport", "food", "walk", "view", "rest"};
    private static final int[] IMAGES = {R.drawable.sg_image_study, R.drawable.sg_image_sport,
            R.drawable.sg_image_food, R.drawable.sg_image_walk, R.drawable.sg_image_view,
            R.drawable.sg_image_rest};
    private static final int[] LABELS = {R.string.sg_image_study, R.string.sg_image_sport,
            R.string.sg_image_food, R.string.sg_image_walk, R.string.sg_image_view,
            R.string.sg_image_rest};
    private final Context context;
    private final int normalTextColor;
    private String selectedCode = CODES[0];

    public ImageAdapter(Context context) {
        this.context = context;
        TypedArray colors = context.obtainStyledAttributes(new int[]{android.R.attr.textColorPrimary});
        normalTextColor = colors.getColor(0, Color.DKGRAY);
        colors.recycle();
    }

    static int indexForCode(String code) {
        for (int i = 0; i < CODES.length; i++) {
            if (CODES[i].equals(code)) return i;
        }
        return 0;
    }

    static String codeAt(int position) { return CODES[position]; }
    static String normalizeCode(String code) { return CODES[indexForCode(code)]; }
    static int imageForCode(String code) { return IMAGES[indexForCode(code)]; }
    static int labelForCode(String code) { return LABELS[indexForCode(code)]; }

    public void selectCode(String code) {
        selectedCode = normalizeCode(code);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return CODES.length; }
    @Override public String getItem(int position) { return CODES[position]; }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        View cell = convertView;
        if (cell == null) {
            cell = LayoutInflater.from(context).inflate(R.layout.item_builtin_image, parent, false);
        }
        boolean selected = CODES[position].equals(selectedCode);
        String label = context.getString(LABELS[position]);
        cell.setActivated(selected);
        ((ImageView) cell.findViewById(R.id.image_thumbnail)).setImageResource(IMAGES[position]);
        TextView name = cell.findViewById(R.id.text_image_label);
        name.setText(selected ? context.getString(R.string.sg_image_selected, label) : label);
        name.setTextColor(selected ? Color.rgb(103, 80, 164) : normalTextColor);
        cell.setContentDescription(selected
                ? context.getString(R.string.sg_image_selected_description, label) : label);
        return cell;
    }
}
