package com.example.myapplication;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.GridView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import com.example.myapplication.data.RecordStore;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    static final String EXTRA_SELECTED_DATE = "selected_date";
    private String selectedDate;
    private Calendar displayedMonth;
    private CalendarAdapter calendarAdapter;
    private RecordStore recordStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calendar);
        recordStore = new RecordStore(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        displayedMonth = Calendar.getInstance();
        displayedMonth.set(Calendar.DAY_OF_MONTH, 1);
        selectedDate = todayDateString();
        if (savedInstanceState != null) {
            displayedMonth.setTimeInMillis(savedInstanceState.getLong("displayed_month",
                    displayedMonth.getTimeInMillis()));
            selectedDate = savedInstanceState.getString("selected_date_state");
        }
        calendarAdapter = new CalendarAdapter(this);
        GridView calendarGrid = findViewById(R.id.grid_calendar);
        calendarGrid.setAdapter(calendarAdapter);
        calendarGrid.setOnItemClickListener((parent, view, position, id) -> {
            String date = calendarAdapter.getItem(position);
            if (date == null) return;
            int error = validateDate(date);
            if (error != 0) {
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
                return;
            }
            selectedDate = date;
            refreshCalendar();
        });
        findViewById(R.id.button_open_check_in).setOnClickListener(v -> openCheckIn());
        findViewById(R.id.button_previous_month).setOnClickListener(v -> changeMonth(-1));
        findViewById(R.id.button_next_month).setOnClickListener(v -> changeMonth(1));
        refreshCalendar();
    }

    private void changeMonth(int amount) {
        displayedMonth = CalendarAdapter.shiftedMonth(displayedMonth, amount);
        selectedDate = CalendarAdapter.defaultSelection(displayedMonth, todayDateString());
        refreshCalendar();
    }

    private void refreshCalendar() {
        String today = todayDateString();
        Set<String> savedDates = new HashSet<>();
        for (String date : CalendarAdapter.buildMonthDates(displayedMonth)) {
            if (date != null && recordStore.isSaved(date)) savedDates.add(date);
        }
        ((TextView) findViewById(R.id.text_month)).setText(
                new SimpleDateFormat("yyyy年M月", Locale.CHINA).format(displayedMonth.getTime()));
        ((TextView) findViewById(R.id.text_selected_date)).setText(selectedDate == null
                ? getString(R.string.sg_no_selected_date)
                : getString(R.string.sg_selected_date, selectedDate));
        ((TextView) findViewById(R.id.text_record_hint)).setText(selectedDate == null
                ? R.string.sg_future_month_hint : savedDates.contains(selectedDate)
                ? R.string.sg_record_exists : R.string.sg_record_hint);
        findViewById(R.id.button_open_check_in).setEnabled(
                selectedDate != null && validateDate(selectedDate) == 0);
        calendarAdapter.update(displayedMonth, selectedDate, today, savedDates);
    }

    @Override protected void onResume() {
        super.onResume();
        if (calendarAdapter != null) refreshCalendar();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putLong("displayed_month", displayedMonth.getTimeInMillis());
        outState.putString("selected_date_state", selectedDate);
        super.onSaveInstanceState(outState);
    }

    private void openCheckIn() {
        int error = validateDate(selectedDate);
        if (error != 0) {
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, CheckInActivity.class);
        intent.putExtra(EXTRA_SELECTED_DATE, selectedDate);
        startActivity(intent);
    }

    static String todayDateString() {
        return dateFormat().format(Calendar.getInstance().getTime());
    }

    private static SimpleDateFormat dateFormat() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        format.setLenient(false);
        return format;
    }

    /** 返回 0 表示有效，其余返回明确的错误提示资源；禁止宽松解析和自动纠正。 */
    static int validateDate(String value) {
        if (value == null || value.trim().isEmpty()) {
            return R.string.sg_date_missing;
        }
        if (!value.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            return R.string.sg_date_format_error;
        }
        SimpleDateFormat format = dateFormat();
        try {
            Date date = format.parse(value);
            if (date == null || !value.equals(format.format(date))) {
                return R.string.sg_date_nonexistent;
            }
            // 将今天也格式化后解析为本地零点，只比较年月日。
            Date today = format.parse(todayDateString());
            if (date.after(today)) {
                return R.string.sg_date_future;
            }
        } catch (ParseException e) {
            return R.string.sg_date_nonexistent;
        }
        return 0;
    }

}
