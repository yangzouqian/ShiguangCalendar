package com.example.myapplication;

import android.os.Bundle;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import com.example.myapplication.data.RecordStore;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** 按日期读取、编辑并保存一条本地生活记录。 */
public class CheckInActivity extends AppCompatActivity {
    private String selectedImageCode = "study";
    private ImageAdapter imageAdapter;
    private String selectedDate;
    private RecordStore recordStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedDate = getIntent().getStringExtra(MainActivity.EXTRA_SELECTED_DATE);
        int error = MainActivity.validateDate(selectedDate);
        if (error != 0) {
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_check_in);
        recordStore = new RecordStore(this);
        fillRecord(recordStore.read(selectedDate));
        ((TextView) findViewById(R.id.text_check_in_date)).setText(
                getString(R.string.sg_check_in_date, selectedDate));
        if (savedInstanceState != null) {
            selectedImageCode = ImageAdapter.normalizeCode(
                    savedInstanceState.getString("selected_image_code"));
        }
        imageAdapter = new ImageAdapter(this);
        GridView images = findViewById(R.id.grid_images);
        images.setAdapter(imageAdapter);
        images.setOnItemClickListener((parent, view, position, id) -> {
            selectedImageCode = imageAdapter.getItem(position);
            updateImagePreview();
        });
        updateImagePreview();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.check_in_root), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        findViewById(R.id.button_return_calendar).setOnClickListener(v -> finish());
        findViewById(R.id.button_save_record).setOnClickListener(v -> saveRecord());
    }

    private void fillRecord(RecordStore.Record record) {
        ((EditText) findViewById(R.id.edit_content)).setText(record.content);
        ((RadioGroup) findViewById(R.id.group_mood)).check("开心".equals(record.mood)
                ? R.id.mood_happy : "低落".equals(record.mood) ? R.id.mood_low : R.id.mood_calm);
        ((CheckBox) findViewById(R.id.tag_study)).setChecked(record.study);
        ((CheckBox) findViewById(R.id.tag_sport)).setChecked(record.sport);
        ((CheckBox) findViewById(R.id.tag_food)).setChecked(record.food);
        ((CheckBox) findViewById(R.id.tag_rest)).setChecked(record.rest);
        selectedImageCode = ImageAdapter.normalizeCode(record.imageCode);
    }

    private void saveRecord() {
        String content = ((EditText) findViewById(R.id.edit_content)).getText().toString();
        int length = RecordStore.contentLength(content);
        if (length == 0 || length > 300) {
            Toast.makeText(this, length == 0 ? R.string.sg_content_empty
                    : R.string.sg_content_too_long, Toast.LENGTH_LONG).show();
            return;
        }
        int dateError = MainActivity.validateDate(selectedDate);
        if (dateError != 0) {
            Toast.makeText(this, dateError, Toast.LENGTH_LONG).show();
            return;
        }
        int moodId = ((RadioGroup) findViewById(R.id.group_mood)).getCheckedRadioButtonId();
        String mood = moodId == R.id.mood_happy ? "开心" : moodId == R.id.mood_low ? "低落" : "平静";
        RecordStore.Record record = new RecordStore.Record(content, mood, selectedImageCode,
                ((CheckBox) findViewById(R.id.tag_study)).isChecked(),
                ((CheckBox) findViewById(R.id.tag_sport)).isChecked(),
                ((CheckBox) findViewById(R.id.tag_food)).isChecked(),
                ((CheckBox) findViewById(R.id.tag_rest)).isChecked(), true);
        if (recordStore.save(selectedDate, record)) finish();
    }

    private void updateImagePreview() {
        imageAdapter.selectCode(selectedImageCode);
        ImageView preview = findViewById(R.id.image_preview);
        preview.setImageResource(ImageAdapter.imageForCode(selectedImageCode));
        preview.setContentDescription(getString(R.string.sg_image_preview,
                getString(ImageAdapter.labelForCode(selectedImageCode))));
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString("selected_image_code", selectedImageCode);
        super.onSaveInstanceState(outState);
    }
}
